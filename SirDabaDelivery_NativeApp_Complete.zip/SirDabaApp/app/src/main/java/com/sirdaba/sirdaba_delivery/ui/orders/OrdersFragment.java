package com.sirdaba.sirdaba_delivery.ui.orders;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.*;
import com.sirdaba.sirdaba_delivery.R;
import com.sirdaba.sirdaba_delivery.api.SirDabaRepository;
import com.sirdaba.sirdaba_delivery.models.*;

import java.util.ArrayList;
import java.util.List;

public class OrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private ProgressBar progressBar;
    private TextView tvEmpty;
    private SirDabaRepository repo;
    private OrdersAdapter adapter;
    private String currentFilter = "pending";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_orders, container, false);

        recyclerView = view.findViewById(R.id.rv_orders);
        progressBar  = view.findViewById(R.id.progress_bar);
        tvEmpty      = view.findViewById(R.id.tv_empty);

        repo = new SirDabaRepository(requireContext());
        adapter = new OrdersAdapter(new ArrayList<>(), this::onOrderAction);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        // Filter tabs
        setupFilterTabs(view);

        loadOrders();
        return view;
    }

    private void setupFilterTabs(View view) {
        Button btnPending  = view.findViewById(R.id.btn_pending);
        Button btnActive   = view.findViewById(R.id.btn_active);
        Button btnCompleted = view.findViewById(R.id.btn_completed);

        btnPending.setOnClickListener(v -> { currentFilter = "pending"; loadOrders(); });
        btnActive.setOnClickListener(v -> { currentFilter = "active"; loadOrders(); });
        btnCompleted.setOnClickListener(v -> { currentFilter = "completed"; loadOrders(); });
    }

    private void loadOrders() {
        progressBar.setVisibility(View.VISIBLE);
        tvEmpty.setVisibility(View.GONE);

        repo.getOrders(currentFilter, new SirDabaRepository.Callback<OrdersResponse>() {
            @Override
            public void onSuccess(OrdersResponse data) {
                requireActivity().runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    List<Order> orders = data.orders != null ? data.orders : new ArrayList<>();
                    adapter.updateOrders(orders);
                    tvEmpty.setVisibility(orders.isEmpty() ? View.VISIBLE : View.GONE);
                });
            }
            @Override
            public void onError(String message) {
                requireActivity().runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void onOrderAction(Order order, String action) {
        switch (action) {
            case "accept":
                confirmAcceptOrder(order);
                break;
            case "deliver_otp":
                showOtpDialog(order);
                break;
            case "cancel":
                showCancelDialog(order);
                break;
        }
    }

    private void confirmAcceptOrder(Order order) {
        new AlertDialog.Builder(requireContext())
            .setTitle("قبول الطلب")
            .setMessage("هل تريد قبول طلب رقم " + order.orderCode + "؟")
            .setPositiveButton("نعم", (d, w) -> acceptOrder(order))
            .setNegativeButton("لا", null)
            .show();
    }

    private void acceptOrder(Order order) {
        repo.acceptOrder(order.id, new SirDabaRepository.Callback<>() {
            @Override
            public void onSuccess(Object data) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "تم قبول الطلب بنجاح", Toast.LENGTH_SHORT).show();
                    loadOrders();
                });
            }
            @Override
            public void onError(String msg) {
                requireActivity().runOnUiThread(() ->
                    Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void showOtpDialog(Order order) {
        EditText etOtp = new EditText(getContext());
        etOtp.setHint("أدخل رمز التسليم OTP");
        etOtp.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        new AlertDialog.Builder(requireContext())
            .setTitle("تأكيد التسليم")
            .setView(etOtp)
            .setPositiveButton("تأكيد", (d, w) -> {
                String otp = etOtp.getText().toString().trim();
                if (!otp.isEmpty()) verifyOtp(order, otp);
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void verifyOtp(Order order, String otp) {
        repo.verifyDeliveryOtp(order.id, otp, new SirDabaRepository.Callback<>() {
            @Override
            public void onSuccess(Object data) {
                requireActivity().runOnUiThread(() -> {
                    Toast.makeText(getContext(), "تم تأكيد التسليم!", Toast.LENGTH_SHORT).show();
                    loadOrders();
                });
            }
            @Override
            public void onError(String msg) {
                requireActivity().runOnUiThread(() ->
                    Toast.makeText(getContext(), "رمز OTP غير صحيح", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void showCancelDialog(Order order) {
        EditText etReason = new EditText(getContext());
        etReason.setHint("سبب الإلغاء");

        new AlertDialog.Builder(requireContext())
            .setTitle("طلب إلغاء")
            .setView(etReason)
            .setPositiveButton("إرسال", (d, w) -> {
                String reason = etReason.getText().toString().trim();
                repo.submitCancelRequest(order.id, reason, new SirDabaRepository.Callback<>() {
                    @Override
                    public void onSuccess(Object data) {
                        requireActivity().runOnUiThread(() ->
                            Toast.makeText(getContext(), "تم إرسال طلب الإلغاء", Toast.LENGTH_SHORT).show());
                    }
                    @Override
                    public void onError(String msg) {
                        requireActivity().runOnUiThread(() ->
                            Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show());
                    }
                });
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }
}
